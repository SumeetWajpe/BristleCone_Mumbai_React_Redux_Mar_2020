import React from 'react';
import './App.css';
import ListOfCourses from './listofcourses.component';

class App extends React.Component {
  render() {

    return <ListOfCourses/>
   
  }
}

export default App;
