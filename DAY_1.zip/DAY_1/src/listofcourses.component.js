import React from 'react';
import Course from "./course.component";

export default class ListOfCourses extends React.Component {
  constructor() {
    super();
    this.courses = [{ name: "React", price: 4000, likes: 200, rating: 4, imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a7/React-icon.svg/1200px-React-icon.svg.png' },
    { name: "Redux", price: 3000, likes: 300, rating: 5, imageUrl: 'https://miro.medium.com/max/2800/0*U2DmhXYumRyXH6X1.png' },
    { name: "Typescript", price: 6000, likes: 800, rating: 3, imageUrl: 'https://raw.githubusercontent.com/remojansen/logo.ts/master/ts.png' },
    { name: "Angular", price: 5000, likes: 500, rating: 4, imageUrl: 'https://d2eip9sf3oo6c2.cloudfront.net/tags/images/000/000/300/full/angular2.png' }];
  }
  render() {

    var coursesToBeCreated = this.courses.map(
      c=><Course coursedetails={c}/>);
    return <div className="row">
        {coursesToBeCreated}
    </div>
  }
}

