import React from 'react';
export default class CourseComponent extends React.Component {
    
    constructor(props){
        super(props);
        this.state = {count:this.props.coursedetails.likes};
    }
    ClickHandler(){
        // change the state to update UI !
        this.setState({count:this.state.count+1})
    }
    render() {
        return <div className="col-md-4">
            <h1> {this.props.coursedetails.name} </h1>
            <img src={this.props.coursedetails.imageUrl}
             height="100px" width="100px"/> <br/>
            <b>Price : </b> {this.props.coursedetails.price} <br/>
            <b>Rating : </b> {this.props.coursedetails.rating} <br/>
            <button className="btn btn-primary"
             onClick={this.ClickHandler.bind(this)}>
                  {this.state.count}
                <span className="glyphicon glyphicon-thumbs-up">

                </span>
              
            </button>
        </div>
    }
}
