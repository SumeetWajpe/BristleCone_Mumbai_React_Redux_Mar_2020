import React from 'react';
import axios from 'axios';


export default class PostsComponent extends React.Component{
 componentDidMount(){
     // ajax !
   let thePromise= axios.get('https://jsonplaceholder.typicode.com/posts');
   thePromise.then(
       response=>console.log(response.data),
       err=>console.log(err)
   )
 }
    render(){       
        return <h1> All Posts !</h1>
    }
}