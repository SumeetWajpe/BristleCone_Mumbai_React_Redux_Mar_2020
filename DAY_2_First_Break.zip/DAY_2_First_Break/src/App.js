import React from 'react';
import './App.css';
import ListOfCourses from './listofcourses.component';
import PostsComponent from './posts.component';

class App extends React.Component {
  render() {

    // return <ListOfCourses/>
    return <PostsComponent/>
   
  }
}

export default App;
