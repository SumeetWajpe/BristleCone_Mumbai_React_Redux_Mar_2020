import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import * as AllActions from "./actions/actionCreators";
import App from './App';

function mapStateToProps(storeData){
        return {
            allPosts:storeData.posts,
            allCourses:storeData.courses
        }
}
function mapDispatchToProps(dispatcherObj){
        return bindActionCreators(AllActions,dispatcherObj)
}

var WrapperApp = connect(mapStateToProps,mapDispatchToProps)(App);
export default WrapperApp;