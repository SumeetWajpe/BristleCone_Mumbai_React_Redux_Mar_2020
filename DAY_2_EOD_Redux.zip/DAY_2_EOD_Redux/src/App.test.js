import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import { shallow } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';

Enzyme.configure({ adapter: new Adapter() });

describe('A test suite for react component',function(){
  it('test app creation',function(){
      var compInstance = shallow(<App />);
      expect(compInstance).toBeDefined();
  });
});


