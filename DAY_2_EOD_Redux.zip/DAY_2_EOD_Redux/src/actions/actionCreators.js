export function IncrementLikes(theId){
    return {type:'INCREMENT_LIKES',theId}
}

export function DeleteCourse(){
    return {type:'DELETE_COURSE'}
}