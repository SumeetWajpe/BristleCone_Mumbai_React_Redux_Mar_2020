export default function posts(originalStore=[],action){
    switch (action.type) {
        case 'ADD_POST':
            console.log('Inside Posts Reducer !');
            return originalStore;

        default:
            console.log(originalStore)
            return originalStore;
    }
   

}