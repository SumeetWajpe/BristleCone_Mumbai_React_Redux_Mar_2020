// combineReducers
import {combineReducers} from 'redux';
import posts from './posts.reducer';
import courses from './courses.reducer';


var rootReducer = combineReducers({
    posts,courses
});

export default rootReducer;