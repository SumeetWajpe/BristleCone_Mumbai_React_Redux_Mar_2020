import axios from 'axios';

export function IncrementLikes(theId){
    return {type:'INCREMENT_LIKES',theId} // same as below !
}

export function DeleteCourse(theId){
    return {type:'DELETE_COURSE',theId:theId}
}


export function FetchCourses(response){
    return {type:'FETCH_COURSES',response}
}

export function FetchPostsAsync(){
    // make an ajax request !
    return (dispatch) => {
        axios.get('https://jsonplaceholder.typicode.com/posts').then(
            response => dispatch(FetchPosts(response.data)),
            err=> console.log(err)
        )
      };    
}
export function FetchPosts(data){
    return {type:'FETCH_POSTS',data}
}