import React, { useState, useEffect } from 'react'
import Axios from 'axios';

export const Users = (props) => {

    const [users,setUsers] = useState([]);

    useEffect(()=>{
        console.log('useEffect == Component Did Mount');
            Axios.get('https://jsonplaceholder.typicode.com/users').then(
                response => setUsers(response.data)
            )
    },[]);
    var usersToBeCreated = users.map(u=><li key={u.id}>{u.name}</li>);
    console.log('Before Calling useEffect == render');

    return( 
        <div>
            <h1> All Users </h1>
           <ul>
               {usersToBeCreated}
           </ul>
        </div>
    )
}
export default Users;