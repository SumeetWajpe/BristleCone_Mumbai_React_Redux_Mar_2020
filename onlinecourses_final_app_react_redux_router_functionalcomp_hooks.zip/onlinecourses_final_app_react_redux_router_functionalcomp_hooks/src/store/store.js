import { createStore,applyMiddleware } from 'redux';
import rootReducer from '../reducers/root.reducer';
import reduxthunk from 'redux-thunk';


// let storeData = {
//     courses: [] , posts: []
// }

// createStore()
var store = createStore(rootReducer,applyMiddleware(reduxthunk));//,window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__());
export default store;