import React from 'react';
import './App.css';
import ListOfCourses from './listofcourses.component';
import PostsComponent from './posts.component';
import PostsReduxComponent from './posts.ajax.redux';
import { Switch, Route, Link } from 'react-router-dom';
import { FunctionalComponent } from './functional.component';
import Likes from './likes.state.hooks';
import Users from './users.effect.hook';

class App extends React.Component {
  render() {

    // return <ListOfCourses  {...this.props}/>
    // return <PostsComponent/>
    // return <PostsReduxComponent {...this.props} />

    return <div>

    {/* <a href="/">Courses</a> |
    <a href="/posts">Posts</a> | 
    <a href="/postsredux">Posts from redux</a>  */}

{/* // Link does not reload the page ! */}
    {/* <Link to="/">Courses</Link> |
    <Link to="/posts">Posts</Link> |
    <Link to="/postsredux">Posts from redux</Link>  */}

    <nav className="navbar navbar-inverse">
  <div className="container-fluid">
    <div className="navbar-header">
      <Link to="/" className="navbar-brand" >Online Courses</Link>
    </div>
    <ul className="nav navbar-nav">
      <li ><Link to="/" >Home</Link></li>
      <li> <Link to="/posts">Posts</Link></li>
      <li><Link to="/postsredux">Posts from redux</Link> </li>
      <li><Link to="/likes">Likes (State Hook)</Link> </li>
      <li><Link to="/users">Users (Effect Hook)</Link> </li>
      <li><Link to="/functional">Functional Component</Link> </li>

    </ul>
    <ul className="nav navbar-nav navbar-right">
      <li><a href="/"><span className="glyphicon glyphicon-user"></span> Sign Up</a></li>
      <li><a href="/"><span className="glyphicon glyphicon-log-in"></span> Login</a></li>
    </ul>
  </div>
</nav>

      <Switch>
        <Route path="/" exact render={()=><ListOfCourses {...this.props} />}></Route>
        <Route path="/posts" component={PostsComponent}></Route>
        <Route path="/postsredux" render={()=><PostsReduxComponent {...this.props} />}></Route>
        <Route path="/functional" render={()=><FunctionalComponent message="Hello !" />}></Route>
        <Route path="/likes" component={Likes}></Route>
        <Route path="/users" component={Users}></Route>


        <Route path="**" render={()=><PostsReduxComponent {...this.props} />}></Route>
        
      </Switch>
    </div>

  }
}

export default App;
