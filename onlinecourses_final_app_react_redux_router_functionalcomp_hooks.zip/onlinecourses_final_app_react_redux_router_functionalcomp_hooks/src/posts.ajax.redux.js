import React from 'react';

export default class PostsReduxComponent extends React.Component {
   componentDidMount() {
            this.props.FetchPostsAsync();
    }
    render() {
    let listsOfPosts = this.props.allPosts.map(p=><li key={p.id}>{p.title}</li>)
        return <div>
            <h1> All Posts !</h1>
            <ul>
                {listsOfPosts}
            </ul>
        </div>
    }
}