var theIndex;
export default function courses(originalStore = [], action) {

    switch (action.type) {
        case 'INCREMENT_LIKES':
            theIndex = originalStore.findIndex(c => c.id == action.theId);
            // stores are immutable !
            // return a newer array !
            return [
                ...originalStore.slice(0, theIndex),
                { ...originalStore[theIndex], likes: originalStore[theIndex].likes + 1 },
                ...originalStore.slice(theIndex + 1)
            ];
        case 'DELETE_COURSE':
            theIndex = originalStore.findIndex(c => c.id == action.theId);
            return [
                ...originalStore.slice(0, theIndex),
                ...originalStore.slice(theIndex + 1)
            ];

        case 'FETCH_COURSES':
            return action.response.data;

        default:
            return originalStore;
    }
}