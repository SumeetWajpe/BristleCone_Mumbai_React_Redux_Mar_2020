import React from 'react';

//1. When we do not have state !
//2. Render/LifeCycle hooks
//3. 'this' is not available , just use props.message

// export function FunctionalComponent(props){
//     return <h1> {props.message}</h1>
// }

export var FunctionalComponent = (props) =>{
    return <h1> {props.message}</h1>
}

