import React, { useState } from 'react';

export const Likes = (props) => {
    // Declare the initial StateHook
    var [likes,setLikes] = useState(100);
    var [dislikes,setDisLikes] = useState(500);

    return(
        <div>
                <p> Likes : {likes}</p>
                <p> Dislikes : {dislikes}</p>
                <input type="button" value="+" className="btn btn-success" onClick={()=>setLikes(likes+1)}/>
                <input type="button" value="-" className="btn btn-danger" onClick={()=>setDisLikes(dislikes-1)}/>
        </div>
    )
}

export default Likes;